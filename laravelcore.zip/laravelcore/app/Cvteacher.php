<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cvteacher extends Model
{
    //
}
