<?php $__env->startSection('content'); ?>
    <div>
        <table class="table table-striped jambo_table bulk_action">
            <thead>
            <tr class="headings">
                <th class="column-title">عکس  </th>
                <th class="column-title">نام  </th>
                <th class="column-title">توضیحات </th>
                <th class="column-title" >کد دسته بندی(موقتا غیر فعال)</th>
                <th>حذف</th>
            </tr>
            </thead>

            <tbody>



            <?php $__currentLoopData = $learns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $learn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="even pointer">
                    <td class=" ">
                        <?php if($learn->ext!="mp4"): ?>
                        <img src="<?php echo e(url('/')); ?>/content/learns/<?php echo e($learn->id); ?>.<?php echo e($learn->ext); ?>" width="50">
                        <?php else: ?>
                            <a class="btn btn-warning" href="<?php echo e(url('/')); ?>/content/learns/<?php echo e($learn->id); ?>.<?php echo e($learn->ext); ?>">مشاهده ویدیو</a>
                        <?php endif; ?>
                    </td>
                    <td class=" "><?php echo e($learn->name); ?></td>
                    <td class=" "><?php echo e($learn->description); ?> </td>
                    <td ><?php echo e($learn->category); ?></td>
                    <td >
                        <a href="<?php echo e(url('/')); ?>/adminSecret/learn/delete/<?php echo e($learn->id); ?>" class="btn btn-danger">حذف</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>