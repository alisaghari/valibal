    <?php $__env->startSection('title'); ?>
    <h1><span class="colored">دوره های</span> آینده سازان</h1>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="best-deal">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">

                        <div class="fh5co-property">
                            <figure>
                                <img src="<?php echo e(url('/')); ?>/content/products/<?php echo e($product->id); ?>.<?php echo e($product->img); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
                                <a href="<?php echo e(url('/')); ?>/product/details/<?php echo e($product->id); ?>" class="tag">اطلاعات بیشتر و ثبت نام</a>
                            </figure>
                            <div class="fh5co-property-innter">
                                <h3><a href="#"><?php echo e($product->name); ?></a></h3>
                                <div class="price-status">
                                    <span class="price"><?php echo e(number_format($product->price)); ?>  ریال  </span>
                                </div>
                                <p><?php echo $product->description; ?> </p>
                            </div>
                            <p class="fh5co-property-specification">
                                <span style="direction: rtl"><strong>مربی</strong> <?php echo e($product->teacher); ?></span>      <span style="direction: rtl">همیشه <strong style="direction: rtl">زمان ثبت نام</strong>   </span>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>