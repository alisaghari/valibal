<?php $__env->startSection('content'); ?>
    <style>
        tr{
            height:50px;
        }
    </style>
    <?php echo e(Form::open(array('url' => 'adminSecret/gallery/add', 'method' => 'post', 'files' => true))); ?>

    <table style="width: 100%;">
        <tr>
            <td style="width: 200px">
               عنوان
            </td>
            <td>
                <?php echo e(Form::text('name','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
                تصویر
            </td>
            <td>
                <?php echo e(Form::file('image' )); ?>

            </td>
        </tr>


        <tr>
            <td>

            </td>
            <td>
                <?php echo e(Form::submit('ثبت',['class'=>'btn btn-primary','style'=>'float: left ; border-radius: 0px'])); ?>

            </td>
        </tr>

    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>