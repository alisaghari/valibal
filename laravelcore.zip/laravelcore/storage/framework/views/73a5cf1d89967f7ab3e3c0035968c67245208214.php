<?php $__env->startSection('content'); ?>
<div>
  <table class="table table-striped jambo_table bulk_action">
    <thead>
      <tr class="headings">
        <th class="column-title">نام </th>
        <th class="column-title">نام خانوادگی </th>
        <th class="column-title">شماره همراه </th>
        <th class="column-title">کد ملی </th>
        <th class="column-title">جنسیت </th>
        <th class="column-title">تاریخ تولد </th>
        <th class="column-title no-link last">تلفن ضروری</th>
        <th class="bulk-actions" colspan="7">
          <a class="antoo" style="color:#fff; font-weight:500;">Bulk Actions ( <span class="action-cnt"> </span> ) <i class="fa fa-chevron-down"></i></a>
        </th>
        <th></th>
      </tr>
    </thead>

    <tbody>



  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr class="even pointer">
    <td class=" "><?php echo e($user->name); ?></td>
    <td class=" "><?php echo e($user->family); ?> </td>
    <td class=" "><?php echo e($user->studentPhone); ?> <i class="success fa fa-long-arrow-up"></i></td>
    <td class=" "><?php echo e($user->nationalCode); ?></td>
    <td class=" "><?php echo e($user->gender); ?></td>
    <td class="a-right a-right "><?php echo e($user->birthday); ?></td>
    <td class=" last"><?php echo e($user->emergencyPhone); ?></td>
    <td class="a-center ">
      <a href="<?php echo e(url('/')); ?>/adminSecret/user/details/<?php echo e($user->id); ?>" class="btn btn-primary">جزئیات</a>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>