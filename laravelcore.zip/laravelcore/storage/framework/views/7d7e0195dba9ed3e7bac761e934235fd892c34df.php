<?php $__env->startSection('title'); ?>
   گالری من
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .my-video3-dimensions{
            height: 240px !important;
        }
        </style>
    <link href="https://vjs.zencdn.net/6.9.0/video-js.css" rel="stylesheet">

    <!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
    <script src="http://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>
    <div id="best-deal">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">

                        <div class="fh5co-property">
                            <figure>
                                <?php if($gallery->ext!="mp4"): ?>
                                    <img src="<?php echo e(url('/')); ?>/content/usergallery/<?php echo e($gallery->id); ?>.<?php echo e($gallery->ext); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
                                <?php else: ?>
                                    <style>
                                        .video-js .vjs-tech {
                                            position: initial !important;
                                        }
                                    </style>
                                    <video id="my-video3" class="video-js img-responsive"  style="width: 100%" controls preload="auto" poster="<?php echo e(url('/')); ?>/content/learns/<?php echo e($gallery->id); ?>_poster.<?php echo e($gallery->extp); ?>" data-setup="{}">
                                        <source src="<?php echo e(url('/')); ?>/content/learns/<?php echo e($gallery->id); ?>.<?php echo e($gallery->ext); ?>" type='video/mp4'>
                                        <source src="<?php echo e(url('/')); ?>/content/learns/<?php echo e($gallery->id); ?>.<?php echo e($gallery->ext); ?>" type='video/webm'>
                                    </video>
                                    <script src="https://vjs.zencdn.net/6.9.0/video.js"></script>
                                <?php endif; ?>
                            </figure>
                            <div class="fh5co-property-innter">
                                <h3><a href="#"><?php echo e($gallery->name); ?></a></h3>
                                <p><?php echo $gallery->description; ?> </p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>
    <script src="https://vjs.zencdn.net/6.9.0/video.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.masterstu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>