<?php $__env->startSection('content'); ?>
    <div>
        <table class="table table-striped jambo_table bulk_action">
            <thead>
            <tr class="headings">
                <th class="column-title">عکس  </th>
                <th class="column-title">نام  </th>
                <th class="column-title">قیمت </th>
                <th class="column-title">مربی </th>
                <th class="column-title">تاریخ شروع </th>
                <th class="column-title">تاریخ پایان </th>
                <th class="column-title">تکرار ثبت نام هرروز</th>
                <th class="column-title" >کد دسته بندی(موقتا غیر فعال)</th>
                <th>حذف</th>
                <th>افزودن برنامه کلاسی</th>
                <th>افراد ثبت نام شده در این دوره</th>
                <th> حضور غیاب</th>
                <th>وضعیت حضور غیاب</th>
            </tr>
            </thead>

            <tbody>



            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="even pointer">
                    <td class=" "><img src="<?php echo e(url('/')); ?>/content/products/<?php echo e($product->id); ?>.<?php echo e($product->img); ?>" width="50"> </td>
                    <td class=" "><?php echo e($product->name); ?></td>
                    <td class=" "><?php echo e($product->price); ?> </td>
                    <td class=" "><?php echo e($product->teacher); ?> </td>
                    <td class=" "><?php echo e($product->start_day); ?></td>
                    <td class=" "><?php echo e($product->end_day); ?></td>
                    <td ><?php echo e($product->loopCourse); ?></td>
                    <td ><?php echo e($product->category); ?></td>
                    <td >
                        <a href="<?php echo e(url('/')); ?>/adminSecret/product/delete/<?php echo e($product->id); ?>" class="btn btn-danger">حذف</a>
                    </td>
                    <td >
                        <a href="<?php echo e(url('/')); ?>/adminSecret/product/program/<?php echo e($product->id); ?>" class="btn btn-danger">افزودن برنامه کلاسی</a>
                    </td>
                    <td >
                        <a href="<?php echo e(url('/')); ?>/adminSecret/product/user/<?php echo e($product->id); ?>" class="btn btn-info">نمایش</a>
                    </td>
                    <td >
                        <a href="<?php echo e(url('/')); ?>/teacher/attend/<?php echo e($product->id); ?>" class="btn btn-info">حضور و غیاب</a>
                    </td>
                    <td >
                        <a href="<?php echo e(url('/')); ?>/adminSecret/class/att/user/find/<?php echo e($product->id); ?>" class="btn btn-info">وضعیت حضور و غیاب</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>