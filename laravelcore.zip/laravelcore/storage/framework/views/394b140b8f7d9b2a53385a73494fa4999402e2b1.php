    <nav role="navigation">
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">صفحه اصلی</a></li>
            <li><a href="<?php echo e(url('/learns')); ?>">آموزش</a></li>
            <li><a href="<?php echo e(url('/noti')); ?>">اعلامیه ها</a></li>
            <li><a href="<?php echo e(url('/teachers')); ?>"> اساتید</a></li>
            <li><a href="<?php echo e(url('/products')); ?>">ثبت نام</a></li>
            <li><a href="<?php echo e(url('/galleries')); ?>">گالری</a></li>
            <li><a href="<?php echo e(url('/ContactUs')); ?>">تماس باما</a></li>
            <?php if($username=="null"): ?>
            <li class="cta"><a  data-toggle="modal" data-target="#exampleModalLong2">ورود / عضویت</a></li>
                <?php else: ?>
                <li class="cta"><a  href="<?php echo e(url('/product/cart/view')); ?>">حساب کاربری من</a></li>
                <?php endif; ?>
        </ul>
    </nav>

    <!--<li class="<?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">Dashboard</li>-->