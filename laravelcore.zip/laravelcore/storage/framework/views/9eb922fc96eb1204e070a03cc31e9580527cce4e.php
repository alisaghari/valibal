<?php $__env->startSection('content'); ?>
    <div>
        <table class="table table-striped jambo_table bulk_action">
            <thead>
            <tr class="headings">
                <th class="column-title">عکس  </th>
                <th class="column-title">نام  </th>
                <th class="column-title">توضیح  </th>
                <th>حذف</th>
            </tr>
            </thead>

            <tbody>



            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="even pointer">
                    <td class=" "><img src="<?php echo e(url('/')); ?>/content/notifications/<?php echo e($notification->id); ?>.<?php echo e($notification->img); ?>" width="50"> </td>
                    <td class=" "><?php echo e($notification->name); ?></td>
                    <td class=" "><?php echo e($notification->description); ?> </td>
                    <td >
                        <a href="<?php echo e(url('/')); ?>/adminSecret/notification/delete/<?php echo e($notification->id); ?>" class="btn btn-danger">حذف</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>