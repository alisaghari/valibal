<?php $__env->startSection('content'); ?>
	<?php echo e(Form::open(array('url' => 'adminSecret/class/att/find/list', 'method' => 'post'))); ?>

	<table style="width: 100%;" class="table table-bordered">
		<tr>
			<td style="width: 200px">
				کد ملی
			</td>
			<td>
				<?php echo e(Form::text('nc','',['class' => 'form-control'])); ?>

				<?php echo e(Form::hidden('product_id',$product_id)); ?>

			</td>

			<td>
				<?php echo e(Form::submit('بررسی وضعیت',['class'=>'btn btn-primary','style'=>'float: left ; border-radius: 0px'])); ?>

			</td>
		</tr>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td style="width: 200px">
					نام خانوادگی	نام
				</td>
				<td>
<?php echo e($user->name); ?> <?php echo e($user->family); ?>

				</td>
				<td style="width: 200px">
					<?php echo e($user->status); ?>

				</td>
				<td>
					<?php echo e($user->date); ?>

				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>