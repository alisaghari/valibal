<?php $__env->startSection('content'); ?>
    <style>
        tr{
            height:50px;
        }
    </style>
    <?php echo e(Form::open(array('url' => 'adminSecret/class/add', 'method' => 'post', 'files' => true))); ?>

    <table style="width: 100%;">
        <tr>
            <td style="width: 200px">
                    نام دوره
            </td>
            <td>
                <?php echo e(Form::text('name','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
                نام مربی
            </td>
            <td>
                <?php echo e(Form::text('teacher','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
                تاریخ شروع دوره
            </td>
            <td>
                <?php echo e(Form::text('startDate','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
               ساعت شروع
            </td>
            <td>
                <?php echo e(Form::text('startTime','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
               lat
            </td>
            <td>
                <?php echo e(Form::text('lat','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
                long
            </td>
            <td>
                <?php echo e(Form::text('long','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
                ظرفیت
            </td>
            <td>
                <?php echo e(Form::text('capacity','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
                تعداد جلسات
            </td>
            <td>
                <?php echo e(Form::text('count','',['class' => 'form-control'])); ?>

            </td>
        </tr>
        <tr>
            <td>
            عکس مربی
            </td>
            <td>
                <?php echo e(Form::file('image' )); ?>

            </td>
        </tr>
        <tr>
            <td>

            </td>
            <td>
                <?php echo e(Form::submit('ثبت',['class'=>'btn btn-primary','style'=>'float: left ; border-radius: 0px'])); ?>

            </td>
        </tr>

    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>