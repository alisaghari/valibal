<?php $__env->startSection('content'); ?>
    <div>
        <table class="table table-striped jambo_table bulk_action">
            <thead>
            <tr class="headings">
                <th class="column-title">عکس  </th>
                <th class="column-title">نام  </th>
                <th class="column-title">مربی </th>
                <th class="column-title">تاریخ شروع </th>
                <th class="column-title">ساعت شروع </th>
                <th>حذف</th>
            </tr>
            </thead>

            <tbody>



            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="even pointer">
                    <td class=" "><img src="<?php echo e(url('/')); ?>/content/class/<?php echo e($product->id); ?>.<?php echo e($product->img); ?>" width="50"> </td>
                    <td class=" "><?php echo e($product->name); ?></td>
                    <td class=" "><?php echo e($product->teacher); ?> </td>
                    <td class=" "><?php echo e($product->start_date); ?></td>
                    <td class=" "><?php echo e($product->start_time); ?></td>
                    <td >
                        <a href="<?php echo e(url('/')); ?>/adminSecret/class/delete/<?php echo e($product->id); ?>" class="btn btn-danger">حذف</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>