<?php $__env->startSection('title'); ?>
    سبد خرید
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .table>tbody>tr>td, .table>tfoot>tr>td{
            vertical-align: middle;
        }
        @media  screen and (max-width: 600px) {
            .table#cart tbody td .form-control{
                width:20%;
                display: inline !important;
            }
            .actions .btn{
                width:36%;
                margin:1.5em 0;
            }

            .actions .btn-info{
                float:left;
            }
            .actions .btn-danger{
                float:right;
            }

            .table#cart thead { display: none; }
            .table#cart tbody td { display: block; padding: .6rem; min-width:320px;}
            .table#cart tbody tr td:first-child { background: #333; color: #fff; }
            .table#cart tbody td:before {
                content: attr(data-th); font-weight: bold;
                display: inline-block; width: 8rem;
            }



            .table#cart tfoot td{display:block; }
            .table#cart tfoot td .btn{display:block;}

        }
    </style>

    <div class="container" style="background-color: white ; -webkit-box-shadow: 0px 0px 18px -2px rgba(0,0,0,0.75);-moz-box-shadow: 0px 0px 18px -2px rgba(0,0,0,0.75);box-shadow: 0px 0px 18px -2px rgba(0,0,0,0.75)">
        <table id="cart" class="table table-hover table-condensed">
            <thead>
            <tr>
                <th style="width:50%">دوره</th>
                <th style="width:10%">قیمت</th>
                <th style="width:10%">تاریخ شروع</th>
                <th style="width:22%" class="text-center">وضعیت تکرار</th>
                <th style="width:10%"></th>
            </tr>
            </thead>
            <tbody>
            <?php
            $totalPrice=  0;
            ?>
            <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td data-th="Product">
                    <div class="row">
                        <div class="col-sm-2 hidden-xs"><img src="<?php echo e(url('/')); ?>/content/products/<?php echo e($cart->id); ?>.<?php echo e($cart->img); ?>" alt="..." class="img-responsive"/></div>
                        <div class="col-sm-10">
                            <h4 class="nomargin"><?php echo e($cart->name); ?></h4>
                            <p><?php echo e($cart->description); ?> </p>
                        </div>
                    </div>
                </td>
                <td data-th="Price"><?php echo e(number_format($cart->price)); ?></td>
                <td data-th="Quantity">
                    <?php echo e($cart->start_day); ?>

                </td>
                <td data-th="Subtotal" class="text-center"> هر روز ثبت نام میشود</td>
                <td class="actions" data-th="">
                    <button class="btn btn-info btn-sm"><i class="fa fa-refresh"></i></button>
                    <a href="<?php echo e(url('/')); ?>//product/cart/delete/<?php echo e($cart->cart_id); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i></a>
                </td>
            </tr>
                <?php
             $totalPrice+=   $cart->price;
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                <td><a href="<?php echo e(url('/')); ?>//products" class="btn btn-warning"><i class="fa fa-angle-left"></i> بازگشت به لیست دوره ها</a></td>
                <td colspan="2" class="hidden-xs"></td>
                <td class="hidden-xs text-center"><strong>مجموع <?php echo e(number_format($totalPrice)); ?></strong></td>
                <td><a href="#" class="btn btn-success btn-block">پرداخت نهایی <i class="fa fa-angle-right"></i></a></td>
            </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.masterstu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>