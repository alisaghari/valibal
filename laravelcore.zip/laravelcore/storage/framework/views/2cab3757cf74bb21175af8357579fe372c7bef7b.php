    <?php $__env->startSection('title'); ?>
    <h1><span class="colored">اعلامیه های </span> آینده سازان</h1>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <link href="https://vjs.zencdn.net/6.9.0/video-js.css" rel="stylesheet">

    <!-- If you'd like to support IE8 (for Video.js versions prior to v7) -->
    <script src="http://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>
    <div id="best-deal">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">

                        <div class="fh5co-property">
                            <figure>
                                <img src="<?php echo e(url('/')); ?>/content/notifications/<?php echo e($notification->id); ?>.<?php echo e($notification->img); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
                                    <a href="<?php echo e(url('/')); ?>/not/details/<?php echo e($notification->id); ?>" class="tag">جزئیات</a>
                            </figure>
                            <div class="fh5co-property-innter">
                                <h3><a href="#"><?php echo e($notification->name); ?></a></h3>
                                <p><?php echo $notification->short_description; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </div>
    </div>
    <script src="https://vjs.zencdn.net/6.9.0/video.js"></script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>