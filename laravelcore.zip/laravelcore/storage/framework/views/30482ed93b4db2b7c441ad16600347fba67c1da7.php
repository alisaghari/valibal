<?php $__env->startSection('content'); ?>
    <?php echo e(Form::open(array('url' => 'adminSecret/product/program/add', 'method' => 'post'))); ?>

    <?php echo e(Form::hidden('product_id',$id)); ?>

    <table class="table table-bordered">
    <tr>
        <th>روز</th>
        <th>8 الی 10</th>
        <th>10 الی 12</th>
        <th>12 الی 14</th>
        <th>14 الی 16</th>
        <th>16 الی 18</th>
        <th>18 الی 20</th>
        <th>20  الی 22</th>
    </tr>
        <tr>
            <td><?php echo e(Form::text('day1','شنبه',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h81','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h101','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h121','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h141','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h161','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h181','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h201','',['class' => 'form-control'])); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::text('day2','یک شنبه',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h82','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h102','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h122','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h142','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h162','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h182','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h202','',['class' => 'form-control'])); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::text('day3','دو شنبه',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h83','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h103','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h123','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h143','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h163','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h183','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h203','',['class' => 'form-control'])); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::text('day4','سه شنبه',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h84','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h104','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h124','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h144','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h164','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h184','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h204','',['class' => 'form-control'])); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::text('day5','چهار شنبه',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h85','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h105','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h125','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h145','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h165','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h185','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h205','',['class' => 'form-control'])); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::text('day6','پنج شنبه',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h86','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h106','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h126','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h146','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h166','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h186','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h206','',['class' => 'form-control'])); ?></td>
        </tr>
        <tr>
            <td><?php echo e(Form::text('day7','جمعه',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h87','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h107','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h127','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h147','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h167','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h187','',['class' => 'form-control'])); ?></td>
            <td><?php echo e(Form::text('h207','',['class' => 'form-control'])); ?></td>
        </tr>
    </table>
    <?php echo e(Form::submit('ثبت',['class'=>'btn btn-primary','style'=>'float: left ; border-radius: 0px ; float:right'])); ?>

    <?php echo e(Form::close()); ?>




    <table class="table table-bordered">
        <tr>
            <th>روز</th>
            <th>8 الی 10</th>
            <th>10 الی 12</th>
            <th>12 الی 14</th>
            <th>14 الی 16</th>
            <th>16 الی 18</th>
            <th>18 الی 20</th>
            <th>20  الی 22</th>
        </tr>
        <?php $__currentLoopData = $Programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($program->day); ?></td>
            <td><?php echo e($program->h8); ?></td>
            <td><?php echo e($program->h10); ?></td>
            <td><?php echo e($program->h12); ?></td>
            <td><?php echo e($program->h14); ?></td>
            <td><?php echo e($program->h16); ?></td>
            <td><?php echo e($program->h18); ?></td>
            <td><?php echo e($program->h20); ?></td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>