    <?php $__env->startSection('title'); ?>
    <h1><span class="colored">آموزش های </span> آینده سازان</h1>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="fh5co-agents" style="background-color: whitesmoke" >
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3 text-center fh5co-heading  animate-box" data-animate-effect="fadeIn">
                    <h2>مربیان توانمند ما</h2>
                    <p>
                        ما با جذب بهترین و شاداب ترین مربیان سعی در این داریم که شما را به هدفتان برسانیم.
                    </p>
                </div>
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 text-center item-block animate-box" data-animate-effect="fadeIn" style="background-color: #f9f9f9">
                    <div class="fh5co-agent">
                        <figure>
                            <img src="<?php echo e(url('/')); ?>/content/teachers/<?php echo e($teacher->id); ?>.<?php echo e($teacher->img); ?>" alt="Free Website Template by FreeHTML5.co">
                        </figure>
                        <h3><?php echo e($teacher->name); ?></h3>
                        <p><?php echo $teacher->description; ?></p>
                        <p><a href="teacher/details/<?php echo e($teacher->id); ?>" class="btn btn-primary btn-outline"> مشاهده رزومه </a></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>



    <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>