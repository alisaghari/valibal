    <?php $__env->startSection('title'); ?>
    <h1><span class="colored">گالرری</span> آینده سازان</h1>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="best-deal">
        <div class="container">

                <?php $i=0; ?>
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                    <?php if($i%3==0): ?>
                                <div class="row">
                        <?php endif; ?>
                    <div class="col-md-4 item-block animate-box" data-animate-effect="fadeIn">

                        <div class="fh5co-property">
                            <figure>
                                <img src="<?php echo e(url('/')); ?>/content/gallery/<?php echo e($gallery->id); ?>.<?php echo e($gallery->img); ?>" alt="Free Website Templates FreeHTML5.co" class="img-responsive">
                                <a  class="tag"><?php echo e($gallery->title); ?></a>
                            </figure>
                        </div>
                    </div>
                                    <?php if($i%3==0): ?>
                                </div>
                                            <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>