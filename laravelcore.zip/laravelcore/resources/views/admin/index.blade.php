@extends('admin.master')

@section('content')

@stop
